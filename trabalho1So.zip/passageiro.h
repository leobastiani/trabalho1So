/******************************************
 * Grupo 3                                *
 *                                        *
 * Leonardo Guarnieri de Bastiani 8910434 *
 * Fábio Satoshi Sumida           8910542 *
 * Paulo Humberto Sapio de Morais 8910591 *
 * Guilherme José Acra            7150306 *
 *                                        *
 * Observações: os arquivos misc facili-  *
 * taram muito o trabalho, por exemplo:   *
 * não precisamos verificar o retorno de  *
 * malloc, pois ela está implementada em  *
 * _malloc no arquivo misc.c.             *
 *                                        *
 * Para compilar utilize make para a ver- *
 * são de release.                        *
 * Make test e make debug para uma versão *
 * com mais detalhes na tela.             *
 *                                        *
 * Utilize a linha de comando --help para *
 * ajuda.                                 *
 ******************************************/

#ifndef __PASSAGEIRO_H__
#define __PASSAGEIRO_H__


/**
 * Vamos fazer uma analogia em um dia de serviço
 * todo passageiro começa em casa
 * vai para o ponto proximo de sua casa
 * chega no trabalho
 * volta para o ponto proximo do trabalho
 * e volta para casa
 */


#include <semaphore.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdio.h>


typedef struct pontoOnibus_t pontoOnibus_t;
typedef struct onibus_t onibus_t;


typedef struct passageiro_t {
	int id;

	// arquivo de trace desse passageiro
	FILE *file;

	// onibus que estou
	onibus_t *onibus;
	pontoOnibus_t *pontoOrigem, *pontoDestino;
	// ponto que o passageiro se encontra
	pontoOnibus_t *pontoOnibus;

	// é o status de cada passageiro, ele pode estar esperando, entrando no onibus, descendo
	int status;
	#define STATUS_emCasa             0
	#define STATUS_noPontoDeCasa      1
	#define STATUS_aCaminhoDoTrabalho 2
	#define STATUS_noTrabalho         3
	#define STATUS_noPontoDoTrabalho  4
	#define STATUS_aCaminhoDeCasa     5
	#define STATUS_deVoltaPontoEmCasa 6

	// estou no ponto e devo esperar o onibus
	sem_t semEsperarOnibusChegar;
} passageiro_t;


typedef struct passageiro_param_t {
	int id;
	int iPontoOrigem;
	int iPontoDestino;
} passageiro_param_t;


/**
 * função necessária para ser chamada antes do Run
 * inicializa um passageiro, mas não define seu ponto de origem
 * e de destino
 * isso deve ser resgatado na função Run pelo parametro
 */
void passageiroInit(passageiro_t *this, int id);



/**
 * devo fazer free de param
 * função que deve ser utilizada como argumento em pthread_create
 * passos que o passageiro deve fazer
 */
void *passageiroRun(void *param);



/**
 * função chamada assim q um passageiro se encerra
 */
void passageiroFinish(passageiro_t *this);




/**
 * requisita que um passageiro suba no onibus
 */
void subirNoOnibus(passageiro_t *this, onibus_t *onibus);




/**
 * simula tanto a chegada de um passageiro até o ponto
 * como a ociosidade do passageiro no ponto de trabalho dele
 * poe o passageiro num ponto de onibus
 */
void caminharAtePonto(passageiro_t *this, pontoOnibus_t *pontoOnibus);




/**
 * executa tudo o que um passageiro precisa para pegar um onibus até o trabalho
 * que é:
 * ir para um ponto
 * pegar um onibus
 * descer no destino
 */
void pegarOnibusOrigemDestino(passageiro_t *this);



/**
 * salva o estado atual do passageiro no arquivo de trace
 */
void atualizarStatus(passageiro_t *this);



#endif // __PASSAGEIRO_H__